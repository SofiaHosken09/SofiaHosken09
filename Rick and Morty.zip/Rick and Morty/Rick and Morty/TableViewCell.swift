//
//  TableViewCell.swift
//  Rick and Morty
//
//  Created by COTEMIG on 20/06/23.
//

import UIKit
import Kingfisher
class TableViewCell: UITableViewCell {

    @IBOutlet weak var label02: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var label01: UILabel!
    func preencher(personagem:Personagem) {
        label01.text = personagem.name
        label02.text = personagem.species
        img.kf.setImage(with: URL(string: personagem.image))
    
    }
}

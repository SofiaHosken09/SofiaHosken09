//
//  ViewController.swift
//  Rick and Morty
//
//  Created by COTEMIG on 20/06/23.
//

import UIKit
import Alamofire

class ViewController: UIViewController, UITableViewDataSource {
  
    var listaPersonagens:[Personagem] = []
    
    @IBOutlet weak var rick: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        rick.dataSource = self
        AF.request("https://rickandmortyapi.com/api/character").responseDecodable(of:Response.self){
            response in
            if let personagens = response.value {
                self.listaPersonagens = personagens.results
                self.rick.reloadData()
            }
        }
    
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        listaPersonagens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = listaPersonagens[indexPath.row]
        if let cell = tableView.dequeueReusableCell(withIdentifier: "celula") as? TableViewCell{
            
            cell.preencher(personagem: item)
            return cell
        }
        
       return UITableViewCell()
    }
   
}

struct Response: Codable {
    let results:[Personagem]
}

struct Personagem: Codable {
    let name: String
    let species: String
    let image: String
}

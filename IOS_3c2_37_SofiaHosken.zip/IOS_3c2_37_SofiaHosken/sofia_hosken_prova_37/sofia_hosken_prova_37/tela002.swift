//
//  tela002.swift
//  sofia_hosken_prova_37
//
//  Created by COTEMIG on 25/04/23.
//

import UIKit

class tela002: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        nome.text = "\(filmes?.nome ?? "")"
        genero.text = "\(filmes?.genero ?? "")"
        ano.text = "\(filmes?.ano ?? "")"
        // Do any additional setup after loading the view.
    }
    
    var filmes: filmes? = nil
    
    @IBOutlet weak var nome: UILabel!
    
    @IBOutlet weak var genero: UILabel!
    

    @IBOutlet weak var ano: UILabel!

}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */




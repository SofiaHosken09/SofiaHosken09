//
//  TableViewCell.swift
//  sofia_hosken_prova_37
//
//  Created by COTEMIG on 25/04/23.
//

import UIKit

class TableViewCell: UITableViewCell {

 

    @IBOutlet weak var label01: UILabel!
    @IBOutlet weak var label02: UILabel!
    @IBOutlet weak var label03: UILabel!
}

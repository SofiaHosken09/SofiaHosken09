//
//  ViewController1.swift
//  sofia_hosken_prova_37
//
//  Created by COTEMIG on 25/04/23.
//

import UIKit

class ViewController1: UIViewController, UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaFilmes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let filmes = listaFilmes [indexPath.row]
        if let cell =
            tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableViewCell {
            cell.label01.text = filmes.genero
            cell.label02.text = filmes.ano
            cell.label03.text = filmes.nome
                return cell
    }
        return UITableViewCell()
    }
    var listaFilmes = [ filmes ] ()
    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource = self
        tableview.delegate = self
        listaFilmes.append(filmes(genero: "Açao", ano: "1998", nome: "The 100 serie "))
        listaFilmes.append(filmes(genero: "Açao", ano: "1998", nome: "Dark serie "))
        listaFilmes.append(filmes(genero: "Açao", ano: "1998", nome: "Naruto serie "))
        listaFilmes.append(filmes(genero: "Açao", ano: "1998", nome: "One piece serie "))
        listaFilmes.append(filmes(genero: "Açao", ano: "1998", nome: "Familia moderna serie "))
        tableview.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let filmes = listaFilmes [indexPath.row]
        performSegue(withIdentifier: "passatela", sender: filmes)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let view = segue.destination as? tela002, let filmes = sender as? filmes {
            view.filmes = filmes
        }
    }

}
//professor eu sei que e serie so que eu confundi na hr de fazer o codigin :) grata gratissima pela atenção!!ß
struct filmes {
    var genero: String
    var ano: String
    var nome: String
}

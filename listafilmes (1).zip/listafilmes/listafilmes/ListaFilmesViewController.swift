//
//  ListaFilmesViewController.swift
//  listafilmes
//
//  Created by COTEMIG on 27/09/44 AH.
//

import UIKit

class ListaFilmesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        nome.text = "\(filmes01?.nome ?? "")"
        tipo.text = "\(filmes01?.genero ?? "")"
        ano.text = "\(filmes01?.ano ?? "")"
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var nome: UILabel!
    @IBOutlet weak var tipo: UILabel!
    @IBOutlet weak var ano: UILabel!
    var filmes01: Filmes? = nil

}

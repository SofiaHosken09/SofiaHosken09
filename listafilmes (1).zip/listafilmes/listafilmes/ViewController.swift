//
//  ViewController.swift
//  listafilmes
//
//  Created by COTEMIG on 20/09/44 AH.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        
        listaFilmes.append(Filmes(nome: "sdadadasdadsO senhor dos Anéis", genero: "Ação", ano: "2010"))
        
        tableView.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaFilmes.count
    
    }
    var listaFilmes = [Filmes]()
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contato = listaFilmes[indexPath.row]
        if let cell = tableView.dequeueReusableCell(withIdentifier: "MinhaCelula", for:indexPath) as? mycell{
            cell.nome.text = contato.nome
            cell.genero.text = contato.genero
            cell.ano.text = contato.ano
            
            
            
            return cell
        }
        
        return UITableViewCell()
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let filmesSelecionados = listaFilmes[indexPath.row]
        performSegue(withIdentifier: "conectarlista", sender: filmesSelecionados)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let vc = segue.destination as? ListaFilmesViewController, let value = sender as? Filmes{
            vc.filmes01 = value
        }
    }
}

struct Filmes {
    var nome: String
    var genero: String
    var ano: String
}

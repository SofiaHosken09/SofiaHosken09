//
//  mycell.swift
//  listafilmes
//
//  Created by COTEMIG on 20/09/44 AH.
//

import UIKit

class mycell: UITableViewCell {

    @IBOutlet weak var nome: UILabel!
    
    @IBOutlet weak var genero: UILabel!
    
    @IBOutlet weak var ano: UILabel!
    
    
    
}

//Exercicio 02

import UIKit

var str = "Hello, playground"
var idade = 90
var name = "Sofia Hosken"
var chave01 = "_3C2_B_Exercicio1"
var chave02="_3C2_B_Exercicio1"
let defaults = UserDefaults.standard


defaults.setValue(name, forKey: chave01)

if let nomeRecuperado = defaults.string( forKey: chave01){
    print(nomeRecuperado)
} else{
print("Não foi possivel recuperar o nome")
}

//Exercicio 02

defaults.setValue(idade, forKey: chave02)

let idadeRecuperado = defaults.integer( forKey: chave02)
print(idadeRecuperado)

//Exercicio 03

struct Pessoa: Codable{
    var name: String
    var age: Int
    
    
}
let pessoa = Pessoa(name: "Jessica 2023", age:43)
do {
    let Json = try JSONEncoder().encode(pessoa)
    defaults.setValue(Json, forKey: chave01)
} catch {
    print(error)
}


do {
    let recebido = defaults.value(forKey: chave01) as! Data
    let receber = try JSONDecoder().decode(Pessoa.self, from: recebido)
    print(receber)
} catch {
    print(error)
}

//Exercicio 04



var pessoas: [Pessoa] = []
pessoas.append(pessoa)

do {
    let Json = try JSONEncoder().encode(pessoas)
    defaults.setValue(Json, forKey: chave01)
} catch {
    print(error)
}


do {
    let recebido = defaults.value(forKey: chave01) as! Data
    let receber = try JSONDecoder().decode([Pessoa].self, from: recebido)
    print(receber)
} catch {
    print(error)
}

//Exercicio 05

// Armazenar o valor no UserDefaults
let nomeSobrenome = "Hosken"
let chave = "Turma_3AA_BB_ExercicioX"

UserDefaults.standard.set(nomeSobrenome, forKey: chave)

// Remover o valor do UserDefaults
UserDefaults.standard.removeObject(forKey: chave)

//Exercicio 06

/*
 Encontre a biblioteca: Procure e encontre a biblioteca Kingfisher que deseja adicionar ao seu projeto. Você pode procurar em repositórios de código, como o GitHub, ou em gerenciadores de pacotes específicos da linguagem Swift, como o CocoaPods ou o Swift Package Manager.

 Configure o gerenciador de pacotes: Se você ainda não tiver um gerenciador de pacotes instalado, instale o CocoaPods ou o Swift Package Manager, dependendo da sua preferência e do gerenciador que a biblioteca Kingfisher suporta.

 Adicione a biblioteca ao projeto:

 Usando o CocoaPods: Abra um terminal, navegue até o diretório raiz do seu projeto e execute o comando:

 csharp
 Copy code
 pod init
 Isso criará um arquivo chamado Podfile. Abra o arquivo Podfile e adicione a seguinte linha no bloco target do seu projeto:

 arduino
 Copy code
 pod 'Kingfisher'
 Salve o arquivo Podfile e execute o comando no terminal:

 Copy code
 pod install
 Isso instalará a biblioteca Kingfisher no seu projeto.

 Usando o Swift Package Manager: No Xcode, vá para File > Swift Packages > Add Package Dependency. Digite a URL do repositório da biblioteca Kingfisher e siga as instruções para adicionar a biblioteca ao seu projeto.

 Importe a biblioteca: Após adicionar a biblioteca ao seu projeto, importe-a no arquivo Swift onde você deseja usá-la. Por exemplo:

 swift
 Copy code
 import Kingfisher
 Utilize a biblioteca: Agora você pode começar a usar as funcionalidades da biblioteca Kingfisher no seu projeto Swift. Consulte a documentação da biblioteca para aprender sobre os métodos e recursos disponíveis.

 Lembre-se de que os detalhes específicos podem variar dependendo do gerenciador de pacotes escolhido e da estrutura do seu projeto Swift. Certifique-se de consultar a documentação relevante para obter instruções detalhadas e atualizadas.
 
 */

//Exercicio 07


struct Contato: Codable {
    let nome: String
    let telefone: String
    let email: String
}

func fetchContatoData() {
    let url = "https://turma3c.com.teste2"
    
    AF.request(url).responseJSON { response in
        switch response.result {
        case .success(let value):
            guard let json = value as? [String: Any],
                  let nome = json["nome"] as? String,
                  let telefone = json["telefone"] as? String,
                  let email = json["email"] as? String else {
                print("Erro ao mapear os dados JSON")
                return
            }
            
            let contato = Contato(nome: nome, telefone: telefone, email: email)
            // Dados recebidos e mapeados para a estrutura Contato
            print("Nome: \(contato.nome)")
            print("Telefone: \(contato.telefone)")
            print("Email: \(contato.email)")
            
        case .failure(let error):
            print("Erro na requisição: \(error.localizedDescription)")
        }
    }
}

// Chamar a função para buscar os dados
fetchContatoData()


// Eercicio 08

    let url = "https://turma3c.com.teste"
    
    AF.request(url).responseJSON { response in
        switch response.result {
        case .success(let value):
            let contato = Contato(nome: nome, telefone: telefone, email: email)
            // Dados recebidos e mapeados para a estrutura Contato
            print("Nome: \(contato.nome)")
            print("Telefone: \(contato.telefone)")
            print("Email: \(contato.email)")
            
        case .failure(let error):
            print("Erro na requisição: \(error.localizedDescription)")
        }
    }


//
//  ViewController.swift
//  atv01
//
//  Created by COTEMIG on 15/08/44 AH.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var text01: UITextField!
    @IBAction func tapgestory(_ sender: Any) {
        performSegue(withIdentifier: "telaC", sender: text01.text)
    }
    
    @IBAction func tapbotton(_ sender: Any) {performSegue(withIdentifier: "telaA", sender: text01.text)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let voce = segue.destination as? ViewControllerB, let valor = sender as? String {
            voce.nome2 = valor
        }
        if let voce = segue.destination as? ViewControllerC, let valor = sender as? String {
            voce.nome3 = valor
        }
    }
}


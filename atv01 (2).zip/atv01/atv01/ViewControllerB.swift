//
//  ViewControllerB.swift
//  atv01
//
//  Created by COTEMIG on 22/08/44 AH.
//

import UIKit

class ViewControllerB: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        conect.text = nome2
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func enviar(_ sender: Any) {
        let text = conect.text
        performSegue(withIdentifier: "mudartela", sender:  text)
    }
    @IBOutlet weak var conect: UILabel!
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let voce = segue.destination as? ViewControllerC, let valor = sender as? String {
            voce.nome3 = valor
        }
    }

    var nome2 : String?
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
